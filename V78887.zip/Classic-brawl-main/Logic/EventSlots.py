import time

class EventSlots:
    Timer = 86400

    maps = [
        # Status = [3 = Nothing, 2 = Star Token, 1 = New Event]
        {
            'ID': 202,
            'Status': 100,
            'Ended': True,
            'Modifier': 0
        },

        {
            'ID': 167,
            'Status': 100,
            'Ended': False,
            'Modifier': 0
        },

        {
            'ID': 203,
            'Status': 100,
            'Ended': True,
            'Modifier': 0
        },

        {
            'ID': 168,
            'Status': 100,
            'Ended': True,
            'Modifier': 0
        },

        {
            'ID': 169,
            'Status': 100,
            'Ended': True,
            'Modifier': 0
        },

        {
            'ID': 204,
            'Status': 100,
            'Ended': True,
            'Modifier': 0
        },

        {
            'ID': 170,
            'Status': 100,
            'Ended': True,
            'Modifier': 0
        }


    ]